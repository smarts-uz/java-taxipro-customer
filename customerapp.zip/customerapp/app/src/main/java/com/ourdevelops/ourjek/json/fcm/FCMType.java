package com.ourdevelops.ourjek.json.fcm;

/**
 * Created by Ourdevelops Team on 11/24/2019.
 */

public class FCMType {
    public static final int ORDER = 1;
    public static final int CHAT = 2;
    public static final int OTHER = 3;
    public static final int OTHER2 = 4;
}
