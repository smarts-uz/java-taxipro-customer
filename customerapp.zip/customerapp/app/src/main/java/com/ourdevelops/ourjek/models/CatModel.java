package com.ourdevelops.ourjek.models;


public class CatModel {

    public String id_kategori_merchant;
    public String nama_kategori;
    public String foto_kategori;
    public String id_fitur;

    public CatModel() {
    }

    public CatModel(String name) {
        this.id_kategori_merchant = id_kategori_merchant;
        this.nama_kategori = nama_kategori;
        this.foto_kategori = foto_kategori;
        this.id_fitur = id_fitur;
    }

}
